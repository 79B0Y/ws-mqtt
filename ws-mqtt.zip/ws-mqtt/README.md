
# WebSocket ↔ MQTT Bridge (Dynamic WebSocket URL via MQTT)

A Python-based bridge that connects to an MQTT broker and listens for WebSocket URLs via MQTT topic. Once a WebSocket URL is received, it connects to the WebSocket server and bridges messages between WebSocket and MQTT.

## Features

- MQTT is used to dynamically set the WebSocket URL
- WebSocket → MQTT message forwarding
- MQTT → WebSocket command forwarding
- Auto-reconnect on WebSocket failure
- YAML configuration for MQTT only

## Installation

```bash
pip install .
```

## Configuration (config.yaml)

```yaml
mqtt:
  broker: "mqtt://localhost:1883"
  username: "your_username"
  password: "your_password"
  publish_topic: "bridge/incoming"
  subscribe_topic: "bridge/outgoing"
  ws_url_topic: "bridge/wsurl"
```

Place this file in the same directory where you run `ws-mqtt`.

## MQTT Protocol

| Topic             | Direction         | Description |
|------------------|-------------------|-------------|
| `bridge/wsurl`   | MQTT → Bridge     | Set the WebSocket URL dynamically |
| `bridge/incoming`| WS → MQTT         | Data from WebSocket gets published here |
| `bridge/outgoing`| MQTT → WS (opt.)  | Commands to be sent to the WebSocket |

## n8n Integration

1. Use **MQTT Publish** node to send WebSocket URL:
   - Topic: `bridge/wsurl`
   - Payload: `"wss://your.websocket.server/path"`

2. Use **MQTT Trigger** node to listen on `bridge/incoming`

3. Use **MQTT Publish** node to send command to `bridge/outgoing`

## Usage

```bash
ws-mqtt
```
