
import yaml
import time
import threading
import websocket
import paho.mqtt.client as mqtt
import os

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config.yaml")

with open(CONFIG_PATH, 'r') as f:
    config = yaml.safe_load(f)

mqtt_cfg = config['mqtt']

# MQTT Setup
client = mqtt.Client()
client.username_pw_set(mqtt_cfg['username'], mqtt_cfg['password'])

ws_url = None
ws = None

def on_connect(client, userdata, flags, rc):
    print("✅ MQTT connected")
    client.subscribe(mqtt_cfg['ws_url_topic'])
    if mqtt_cfg.get('subscribe_topic'):
        client.subscribe(mqtt_cfg['subscribe_topic'])

def on_message(client, userdata, msg):
    global ws_url
    if msg.topic == mqtt_cfg['ws_url_topic']:
        ws_url = msg.payload.decode()
        print(f"🔗 Received WebSocket URL: {ws_url}")
        start_ws()
    elif msg.topic == mqtt_cfg['subscribe_topic']:
        if ws and ws.sock and ws.sock.connected:
            print(f"🔁 MQTT → WS: {msg.payload.decode()}")
            ws.send(msg.payload.decode())

client.on_connect = on_connect
client.on_message = on_message
client.connect(mqtt_cfg['broker'].replace("mqtt://", ""), 1883, 60)

def mqtt_loop():
    client.loop_forever()

mqtt_thread = threading.Thread(target=mqtt_loop)
mqtt_thread.daemon = True
mqtt_thread.start()

# WebSocket Setup
def on_message_ws(wsapp, message):
    print(f"📨 WS Received: {message}")
    client.publish(mqtt_cfg['publish_topic'], message)

def on_error(wsapp, error):
    print(f"❌ WS Error: {error}")

def on_close(wsapp, close_status_code, close_msg):
    print("⚠️ WS Closed, waiting for new URL...")

def on_open(wsapp):
    print("🔗 WebSocket connected")

def start_ws():
    global ws
    if ws_url:
        def run():
            global ws
            ws = websocket.WebSocketApp(
                ws_url,
                on_open=on_open,
                on_message=on_message_ws,
                on_error=on_error,
                on_close=on_close
            )
            ws.run_forever()
        thread = threading.Thread(target=run)
        thread.daemon = True
        thread.start()

def main():
    print("📡 Waiting for WebSocket URL via MQTT...")
    while True:
        time.sleep(1)

if __name__ == "__main__":
    main()
