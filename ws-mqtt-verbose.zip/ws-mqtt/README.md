
# WebSocket ↔ MQTT Bridge (Verbose Logging + Status Reporting)

A bridge that connects to a WebSocket server and MQTT broker, with enhanced logging and support for status reporting via MQTT.

## Features

- ✅ Verbose logging: prints all send/receive events for MQTT and WebSocket
- 🔁 Reconnects on disconnect
- 🛰️ Publishes internal status to MQTT topic `bridge/status`
- ⚙️ Configuration via `config.yaml`
- 🧩 Integrates with n8n via MQTT nodes

## Installation

```bash
pip install .
```

## Configuration (`config.yaml`)

```yaml
mqtt:
  broker: "127.0.0.1"
  username: "admin"
  password: "admin"
  publish_topic: "bridge/incoming"
  subscribe_topic: "bridge/outgoing"
  ws_url_topic: "bridge/wsurl"
  status_topic: "bridge/status"
```

## MQTT Topics

| Topic             | Direction         | Description                            |
|------------------|-------------------|----------------------------------------|
| `bridge/wsurl`   | MQTT → Bridge     | Set the WebSocket URL                  |
| `bridge/incoming`| WS → MQTT         | Data received from WebSocket           |
| `bridge/outgoing`| MQTT → WS         | Commands to WebSocket                  |
| `bridge/status`  | Bridge → MQTT     | Publishes bridge status info as JSON  |

## Run

```bash
ws-mqtt
```

Logs show full message flow.
